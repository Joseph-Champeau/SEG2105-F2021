package com.example.deliverable1fixed;

public class Class {

    public String name;
    public String description;

    public Class() {}

    public Class(String name, String description) {
        this.name = name;
        this.description = description;
    }

}
